"""
cyclic_correlation.


"""
from .cyclic_correlation import cyclic_corr, check_inputs_define_limits

__version__ = "0.1.0"
__author__ = 'Andrea Novero'
__credits__ = 'SIGNET Laboratory, University of Padova'