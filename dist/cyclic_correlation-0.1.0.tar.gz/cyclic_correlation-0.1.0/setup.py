from setuptools import setup, find_packages

setup(
    name="cyclic_correlation",
    version="0.1.0",
    description="Cyclic cross-correlation utilities",
    author="Andrea Novero",
    author_email="your@email.com",
    packages=find_packages(),
    install_requires=["numpy"],
    python_requires=">=3.6",
    license="MIT",
    url="https://github.com/noveroandrea/cyclic_correlation", 
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
)